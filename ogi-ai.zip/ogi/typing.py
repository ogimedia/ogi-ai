from typing import Any

from insightface.app.common import Face
from ogi.FaceSet import FaceSet
import numpy

Face = Face
FaceSet = FaceSet
Frame = numpy.ndarray[Any, Any]
