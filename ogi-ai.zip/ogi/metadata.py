name = 'OGI AI'
version = '1.2.3'
